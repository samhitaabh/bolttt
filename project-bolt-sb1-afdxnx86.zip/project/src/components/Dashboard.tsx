import React from 'react';
import { Activity, Heart, Thermometer, Droplets, FootprintsIcon } from 'lucide-react';
import { HealthMetricCard } from './HealthMetricCard';
import { HealthChart } from './HealthChart';
import { AlertsList } from './AlertsList';
import { mockHealthData } from '../utils/mockData';

export function Dashboard() {
  const latestData = mockHealthData[mockHealthData.length - 1];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">Health Dashboard</h1>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          <HealthMetricCard
            title="Heart Rate"
            value={`${latestData.heartRate}`}
            unit="bpm"
            icon={Heart}
            trend={+5}
          />
          <HealthMetricCard
            title="Blood Pressure"
            value={`${latestData.bloodPressure.systolic}/${latestData.bloodPressure.diastolic}`}
            unit="mmHg"
            icon={Activity}
            trend={-2}
          />
          <HealthMetricCard
            title="Glucose Level"
            value={`${latestData.glucoseLevel}`}
            unit="mg/dL"
            icon={Droplets}
            trend={+8}
          />
          <HealthMetricCard
            title="Steps"
            value={`${latestData.steps}`}
            unit="steps"
            icon={FootprintsIcon}
            trend={+1200}
          />
        </div>

        <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-2">
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-medium mb-4">Heart Rate Trend</h2>
            <HealthChart data={mockHealthData} dataKey="heartRate" />
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-medium mb-4">Glucose Level Trend</h2>
            <HealthChart data={mockHealthData} dataKey="glucoseLevel" />
          </div>
        </div>

        <div className="mt-8">
          <AlertsList />
        </div>
      </main>
    </div>
  );
}