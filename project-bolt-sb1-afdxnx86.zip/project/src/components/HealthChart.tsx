import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { format } from 'date-fns';
import { HealthData } from '../types/health';

interface HealthChartProps {
  data: HealthData[];
  dataKey: keyof HealthData | 'bloodPressure.systolic' | 'bloodPressure.diastolic';
}

export function HealthChart({ data, dataKey }: HealthChartProps) {
  const formatXAxis = (timestamp: number) => format(new Date(timestamp), 'HH:mm');

  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis
            dataKey="timestamp"
            tickFormatter={formatXAxis}
            type="number"
            domain={['auto', 'auto']}
          />
          <YAxis />
          <Tooltip
            labelFormatter={(label) => format(new Date(label), 'HH:mm:ss')}
            formatter={(value) => [value, dataKey.split('.').pop()]}
          />
          <Line
            type="monotone"
            dataKey={dataKey}
            stroke="#3b82f6"
            strokeWidth={2}
            dot={false}
            activeDot={{ r: 8 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}