import React from 'react';
import { AlertTriangle, Info } from 'lucide-react';
import { mockAlerts } from '../utils/mockData';
import { format } from 'date-fns';

export function AlertsList() {
  return (
    <div className="bg-white shadow rounded-lg">
      <div className="p-6">
        <h2 className="text-lg font-medium mb-4">Health Alerts</h2>
        <div className="space-y-4">
          {mockAlerts.map((alert) => (
            <div
              key={alert.id}
              className={`flex items-start p-4 rounded-lg ${
                alert.type === 'danger'
                  ? 'bg-red-50'
                  : alert.type === 'warning'
                  ? 'bg-yellow-50'
                  : 'bg-blue-50'
              }`}
            >
              {alert.type === 'danger' || alert.type === 'warning' ? (
                <AlertTriangle
                  className={`h-5 w-5 ${
                    alert.type === 'danger' ? 'text-red-400' : 'text-yellow-400'
                  }`}
                />
              ) : (
                <Info className="h-5 w-5 text-blue-400" />
              )}
              <div className="ml-3">
                <p
                  className={`text-sm font-medium ${
                    alert.type === 'danger'
                      ? 'text-red-800'
                      : alert.type === 'warning'
                      ? 'text-yellow-800'
                      : 'text-blue-800'
                  }`}
                >
                  {alert.message}
                </p>
                <p className="mt-1 text-sm text-gray-500">
                  {format(new Date(alert.timestamp), 'MMM d, yyyy HH:mm')}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}