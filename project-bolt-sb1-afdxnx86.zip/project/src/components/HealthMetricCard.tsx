import React from 'react';
import { LucideIcon } from 'lucide-react';

interface HealthMetricCardProps {
  title: string;
  value: string;
  unit: string;
  icon: LucideIcon;
  trend: number;
}

export function HealthMetricCard({ title, value, unit, icon: Icon, trend }: HealthMetricCardProps) {
  const trendColor = trend >= 0 ? 'text-green-500' : 'text-red-500';
  const trendSymbol = trend >= 0 ? '↑' : '↓';

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center">
        <div className="p-3 rounded-full bg-blue-100">
          <Icon className="h-6 w-6 text-blue-600" />
        </div>
        <div className="ml-4">
          <h3 className="text-sm font-medium text-gray-500">{title}</h3>
          <div className="flex items-baseline">
            <p className="text-2xl font-semibold text-gray-900">{value}</p>
            <p className="ml-2 text-sm text-gray-500">{unit}</p>
          </div>
          <p className={`text-sm ${trendColor} flex items-center mt-1`}>
            {trendSymbol} {Math.abs(trend)}
          </p>
        </div>
      </div>
    </div>
  );
}