export interface HealthData {
  timestamp: number;
  heartRate: number;
  bloodPressure: {
    systolic: number;
    diastolic: number;
  };
  glucoseLevel: number;
  temperature: number;
  steps: number;
}

export interface HealthAlert {
  id: string;
  type: 'warning' | 'danger' | 'info';
  message: string;
  timestamp: number;
}