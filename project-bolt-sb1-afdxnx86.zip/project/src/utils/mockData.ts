import { HealthData, HealthAlert } from '../types/health';

// Generate mock health data for the last 24 hours
const generateMockHealthData = (): HealthData[] => {
  const data: HealthData[] = [];
  const now = Date.now();
  const hourInMs = 3600000;

  for (let i = 24; i >= 0; i--) {
    data.push({
      timestamp: now - i * hourInMs,
      heartRate: 60 + Math.random() * 30,
      bloodPressure: {
        systolic: 110 + Math.random() * 20,
        diastolic: 70 + Math.random() * 15,
      },
      glucoseLevel: 80 + Math.random() * 40,
      temperature: 36.5 + Math.random() * 1,
      steps: Math.floor(Math.random() * 1000),
    });
  }

  return data;
};

export const mockHealthData = generateMockHealthData();

export const mockAlerts: HealthAlert[] = [
  {
    id: '1',
    type: 'danger',
    message: 'High heart rate detected: 120 bpm',
    timestamp: Date.now() - 1800000,
  },
  {
    id: '2',
    type: 'warning',
    message: 'Glucose level trending higher than usual',
    timestamp: Date.now() - 3600000,
  },
  {
    id: '3',
    type: 'info',
    message: 'Daily step goal achieved!',
    timestamp: Date.now() - 7200000,
  },
];